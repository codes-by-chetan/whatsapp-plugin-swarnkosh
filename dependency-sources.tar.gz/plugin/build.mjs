import { build } from 'esbuild'
import { mkdir, writeFile, readFile, stat, readdir } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { gzipSync } from 'node:zlib'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
const root = path.dirname(fileURLToPath(import.meta.url))
const args = process.argv.slice(2)
if (args.some(arg => arg !== '--no-app-seed')) throw Error('Usage: node build.mjs [--no-app-seed]')
// dist/ is reserved for the signed, publishable update repository.
const out = path.join(root, '.build')
await mkdir(out, { recursive: true })
const result = await build({ absWorkingDir: root, entryPoints: [path.join(root, 'engine.mjs')], outfile: path.join(out, 'engine.mjs'), bundle: true, platform: 'node', format: 'esm', target: 'node22', minify: false, metafile: true,
  banner: { js: "import { createRequire as __swarnRequire } from 'node:module'; const require = __swarnRequire(import.meta.url);" },
  external: ['sharp', 'jimp', 'audio-decode', 'link-preview-js'],
})
const bytes = await readFile(path.join(out, 'engine.mjs'))
const metadata = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'))
const artifact = { version: metadata.version, protocol: 1, authFormat: 1, nodeMajorMin: 22, entry: 'engine.mjs', files: [{ path: 'engine.mjs', sha256: createHash('sha256').update(bytes).digest('hex'), content: bytes.toString('base64') }] }
await writeFile(path.join(out, 'whatsapp-engine.json'), JSON.stringify(artifact))
const bundledInputs = new Set(Object.values(result.metafile.outputs).flatMap(output =>
  Object.entries(output.inputs).filter(([, input]) => input.bytesInOutput > 0).map(([name]) => name)))
const packages = new Map()
// Tree-shaken imports still need to resolve when rebuilding from source.
const sourcePackages = new Map()
for (const input of Object.keys(result.metafile.inputs)) {
  if (!input.replaceAll('\\', '/').includes('node_modules/')) continue
  let directory = path.dirname(path.resolve(root, input))
  while (directory !== path.dirname(directory)) {
    const packageFile = path.join(directory, 'package.json')
    const contents = await readFile(packageFile, 'utf8').catch(error => {
      if (error.code === 'ENOENT') return null
      throw error
    })
    const pkg = contents ? JSON.parse(contents) : null
    if (pkg?.name) {
      const relative = path.relative(root, directory).replaceAll('\\', '/')
      if (!relative.startsWith('node_modules/') || relative.includes('../')) throw Error(`Dependency resolved outside the plugin: ${pkg.name}`)
      sourcePackages.set(directory, { directory, pkg })
      if (bundledInputs.has(input)) packages.set(`${pkg.name}@${pkg.version}`, { directory, pkg })
      break
    }
    directory = path.dirname(directory)
  }
}
const notices = ['Swarnkosh WhatsApp engine - third-party notices',
  'This distribution bundles the following third-party packages. Their license terms and notices apply to those components.',
  'Optional packages excluded from the bundle are not included in this list.']
for (const [name, { directory, pkg }] of [...packages].sort(([a], [b]) => a.localeCompare(b))) {
  const licenses = (await readdir(directory, { withFileTypes: true }))
    .filter(file => file.isFile() && /^(license|licence|copying|notice)(\b|[._-])/i.test(file.name))
    .map(file => file.name).sort()
  notices.push(`\n${'='.repeat(80)}\n${name}\nDeclared license: ${typeof pkg.license === 'string' ? pkg.license : JSON.stringify(pkg.license ?? pkg.licenses ?? 'Not declared')}`)
  for (const file of licenses) notices.push(`\n--- ${file} ---\n${await readFile(path.join(directory, file), 'utf8')}`)
  if (!licenses.length) notices.push('No separate license or notice file was included in the installed package.')
}
await writeFile(path.join(out, 'THIRD_PARTY_NOTICES.txt'), `${notices.join('\n')}\n`)
const sourceInfo = `# Sources included with this engine release\n\n` +
  `Engine version: ${metadata.version}\n\n` +
  '`dependency-sources.tar.gz` contains the engine source/build files under `plugin/` and the exact installed npm package files for dependencies resolved during the build under `plugin/node_modules/`. This includes bundled packages and imports removed by tree shaking that the bundler must still resolve. Existing license files and copyright notices are preserved. No Swarnkosh desktop application source, credentials or signing keys are included.\n\n' +
  '## Reproducing the JavaScript bundle\n\n' +
  'Extract the archive, enter `plugin/`, use Node.js 22 or later, then run `npm ci --ignore-scripts` and `node build.mjs --no-app-seed`. Installation downloads the exact dependencies and build tooling from package-lock.json. The unsigned outputs appear under `.build/`. Signing and repository publication are separate operations and are not needed to rebuild the engine.\n\n' +
  '## Scope and limitations\n\n' +
  'This is an archive of published npm package contents, not a complete archive of every upstream source repository. Build tools and platform executables are not included. The published whatsapp-rust-bridge package contains precompiled WebAssembly without its original Rust/Cargo sources; its upstream is https://github.com/jlucaso1/whatsapp-rust-bridge. The full installed libsignal package is included and declares GPL-3.0. Its upstream is https://github.com/WhiskeySockets/libsignal-node. Read THIRD_PARTY_NOTICES.txt and assess the license obligations before distribution; this archive is not a guarantee of legal compliance.\n\n' +
  '## Bundled package versions\n\n' + [...packages.keys()].sort().map(name => `- ${name}`).join('\n') + '\n\n' +
  '## Additional packages used during build resolution\n\n' + [...new Set([...sourcePackages.values()].map(({ pkg }) => `${pkg.name}@${pkg.version}`))].filter(name => !packages.has(name)).sort().map(name => `- ${name}`).join('\n') + '\n'
await writeFile(path.join(out, 'SOURCES.md'), sourceInfo)

// A deterministic POSIX tar archive, generated without a system tar executable.
const archive = []
function appendArchiveFile(name, bytes) {
  const header = Buffer.alloc(512)
  const split = name.lastIndexOf('/')
  const filename = Buffer.byteLength(name) <= 100 ? name : name.slice(split + 1)
  const prefix = Buffer.byteLength(name) <= 100 ? '' : name.slice(0, split)
  if (Buffer.byteLength(filename) > 100 || Buffer.byteLength(prefix) > 155) throw Error(`Archive path too long: ${name}`)
  header.write(filename, 0, 100, 'utf8')
  const octal = (value, offset, length) => header.write(value.toString(8).padStart(length - 1, '0') + '\0', offset, length, 'ascii')
  octal(0o644, 100, 8); octal(0, 108, 8); octal(0, 116, 8)
  octal(bytes.length, 124, 12); octal(0, 136, 12)
  header.fill(32, 148, 156); header[156] = 48
  header.write('ustar\0', 257, 6, 'ascii'); header.write('00', 263, 2, 'ascii')
  header.write(prefix, 345, 155, 'utf8')
  header.write([...header].reduce((total, value) => total + value, 0).toString(8).padStart(6, '0') + '\0 ', 148, 8, 'ascii')
  archive.push(header, bytes, Buffer.alloc((512 - bytes.length % 512) % 512))
}
async function appendSourceTree(directory, target) {
  for (const item of (await readdir(directory, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
    if (item.name === 'node_modules' || item.name === '.git') continue
    if (item.isSymbolicLink()) throw Error(`Unexpected source symlink: ${target}/${item.name}`)
    if (item.isDirectory()) await appendSourceTree(path.join(directory, item.name), `${target}/${item.name}`)
    else if (item.isFile()) appendArchiveFile(`${target}/${item.name}`, await readFile(path.join(directory, item.name)))
  }
}
for (const file of ['engine.mjs', 'cloud.mjs', 'build.mjs', 'package.json', 'package-lock.json'])
  appendArchiveFile(`plugin/${file}`, await readFile(path.join(root, file)))
for (const [, { directory }] of [...sourcePackages].sort(([a], [b]) => a.localeCompare(b))) {
  const packagePath = path.relative(root, directory).replaceAll('\\', '/')
  if (!packagePath.startsWith('node_modules/') || packagePath.includes('../')) throw Error('Source dependencies must be installed inside the plugin package.')
  await appendSourceTree(directory, `plugin/${packagePath}`)
}
appendArchiveFile('SOURCES.md', Buffer.from(sourceInfo))
appendArchiveFile('THIRD_PARTY_NOTICES.txt', Buffer.from(`${notices.join('\n')}\n`))
archive.push(Buffer.alloc(1024))
await writeFile(path.join(out, 'dependency-sources.tar.gz'), gzipSync(Buffer.concat(archive), { level: 9 }))
const resources = path.resolve(root, '../../resources/whatsapp')
if (!args.includes('--no-app-seed') && await stat(resources).then(value => value.isDirectory(), error => {
  if (error.code === 'ENOENT') return false
  throw error
})) await writeFile(path.join(resources, 'seed.json'), JSON.stringify(artifact))
console.log(`Built unsigned WhatsApp provider package in .build (${bytes.length} bytes).`)
