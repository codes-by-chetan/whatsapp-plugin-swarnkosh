// Official API adapter. Use an approved utility template with a PDF header.
export function createCloud({ emit, config, fetchImpl = fetch }) {
  const cloud = config.cloud
  const base = `https://graph.facebook.com/${cloud.graphVersion}/${cloud.phoneNumberId}`
  async function request(endpoint, body) {
    const response = await fetchImpl(`${base}/${endpoint}`, {
      method: 'POST', headers: { Authorization: `Bearer ${cloud.accessToken}`, ...(body instanceof FormData ? {} : { 'Content-Type': 'application/json' }) },
      body: body instanceof FormData ? body : JSON.stringify(body), signal: AbortSignal.timeout(45000), redirect: 'error',
    })
    const data = await response.json()
    if (!response.ok || data.error) {
      const error = new Error(`Official WhatsApp request was rejected (code ${Number(data.error?.code) || response.status}). Check account permissions, token and approved template.`)
      error.definitive = response.status >= 400 && response.status < 500
      throw error
    }
    return data
  }
  return {
    async connect() {
      if (!cloud.accessToken || !/^v\d+\.\d+$/.test(cloud.graphVersion) || !/^\d+$/.test(cloud.phoneNumberId)) throw Error('Complete the official WhatsApp account settings.')
      // Configured, not a claim that Meta accepted the token or template.
      emit({ kind: 'status', state: 'connected', account: `Official account ${cloud.phoneNumberId}` })
    },
    async send(input) {
      let submitting = false
      try {
        const media = new FormData()
        media.set('messaging_product', 'whatsapp')
        media.set('type', 'application/pdf')
        media.set('file', new Blob([input.pdf], { type: 'application/pdf' }), input.filename)
        const uploaded = await request('media', media)
        if (typeof uploaded.id !== 'string') throw Error('The official provider did not return a media identifier.')
        const components = [{ type: 'header', parameters: [{ type: 'document', document: { id: uploaded.id, filename: input.filename } }] }]
        if (cloud.bodyParameters.length) components.push({ type: 'body', parameters: cloud.bodyParameters.map(key => ({ type: 'text', text: input[key] })) })
        submitting = true
        const result = await request('messages', {
          messaging_product: 'whatsapp', recipient_type: 'individual', to: input.to.slice(1), type: 'template',
          template: { name: cloud.templateName, language: { code: cloud.templateLanguage }, components },
        })
        if (!result.messages?.[0]?.id) return { state: 'unknown', error: 'Provider acceptance could not be confirmed. Check before resending.' }
        return { state: 'accepted', messageId: result.messages[0].id }
      } catch (error) {
        return { state: !submitting || error.definitive ? 'rejected' : 'unknown', error: error.definitive ? error.message : submitting ? 'Delivery could not be confirmed. Check before resending.' : 'PDF upload failed. No message was submitted.' }
      }
    },
    async stop() {},
    async unlink() {},
  }
}
