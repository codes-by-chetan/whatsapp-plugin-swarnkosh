import makeWASocket, { BufferJSON, initAuthCreds, proto, DisconnectReason, Browsers } from '@whiskeysockets/baileys'
import pino from 'pino'
import QRCode from 'qrcode'
import { createCloud } from './cloud.mjs'
import metadata from './package.json' with { type: 'json' }

export const contract = { protocol: 1, authFormat: 1, version: metadata.version, providers: ['baileys', 'cloud'] }
export async function createEngine({ storage, emit, config }) {
  if (config.provider === 'cloud') return createCloud({ emit, config })
  let sock, timer, stopped = true, generation = 0, reconnects = 0, connected = false
  let writes = Promise.resolve()
  const logger = pino({ level: 'silent' })
  const encode = value => JSON.stringify(value, BufferJSON.replacer)
  const decode = value => value == null ? null : JSON.parse(value, BufferJSON.reviver)
  const save = changes => {
    const operation = writes.then(() => storage.set(changes))
    writes = operation
    operation.catch(() => { stopped = true; connected = false; clearTimeout(timer); sock?.end(undefined); emit({ kind: 'status', state: 'error', error: 'WhatsApp session could not be saved. Reconnect after repairing secure storage.' }) })
    return operation
  }
  const creds = decode(await storage.get('creds')) || initAuthCreds()
  const keys = {
    async get(type, ids) {
      const entries = await Promise.all(ids.map(async id => {
        let value = decode(await storage.get(`key:${type}:${id}`))
        if (type === 'app-state-sync-key' && value) value = proto.Message.AppStateSyncKeyData.create(value)
        return [id, value]
      }))
      return Object.fromEntries(entries)
    },
    async set(data) {
      const changes = {}
      for (const [type, values] of Object.entries(data)) for (const [id, value] of Object.entries(values)) changes[`key:${type}:${id}`] = value == null ? null : encode(value)
      await save(changes)
    },
  }
  async function connect() {
    clearTimeout(timer)
    stopped = false
    connected = false
    const current = ++generation
    sock?.ev.removeAllListeners('connection.update')
    sock?.end(undefined)
    emit({ kind: 'status', state: 'connecting' })
    const socket = sock = makeWASocket({
      auth: { creds, keys }, logger, browser: Browsers.ubuntu('Desktop'), syncFullHistory: false,
      markOnlineOnConnect: false, generateHighQualityLinkPreview: false,
      shouldSyncHistoryMessage: () => false,
      getMessage: async key => decode(await storage.get(`message:${key.id}`))?.message,
    })
    socket.ev.on('creds.update', update => { Object.assign(creds, update); void save({ creds: encode(creds) }).catch(() => {}) })
    socket.ev.on('connection.update', async update => {
      if (stopped || current !== generation) return
      if (update.qr) {
        const qr = await QRCode.toDataURL(update.qr)
        if (!stopped && current === generation) emit({ kind: 'status', state: 'pairing', qr })
      }
      if (update.connection === 'open') {
        connected = true; reconnects = 0
        emit({ kind: 'status', state: 'connected', account: socket.user?.id?.split(':')[0]?.split('@')[0] || 'Linked account' })
      }
      if (update.connection === 'close') {
        connected = false
        const code = update.lastDisconnect?.error?.output?.statusCode
        if ([DisconnectReason.loggedOut, DisconnectReason.badSession, DisconnectReason.connectionReplaced].includes(code)) {
          stopped = true
          emit({ kind: 'status', state: 'error', error: 'The linked account needs attention. Check linked devices, then unlink and pair again if necessary.' })
          return
        }
        emit({ kind: 'status', state: 'disconnected' })
        timer = setTimeout(() => connect().catch(() => emit({ kind: 'status', state: 'error', error: 'Unable to reconnect WhatsApp.' })), Math.min(60000, 2000 * 2 ** Math.min(++reconnects, 5)) + Math.random() * 1000)
      }
    })
    socket.ev.on('messages.update', updates => {
      for (const { key, update } of updates) if (key.fromMe && key.id && Number(update.status) >= 3)
        emit({ kind: 'receipt', messageId: key.id, state: Number(update.status) >= 4 ? 'read' : 'delivered' })
    })
  }
  async function stop() {
    stopped = true; connected = false; generation++; clearTimeout(timer)
    sock?.ev.removeAllListeners('connection.update'); sock?.end(undefined)
    await writes
    sock = undefined
  }
  return {
    connect,
    async send(input) {
      if (!connected || !sock) return { state: 'rejected', error: 'WhatsApp is not connected. No message was submitted.' }
      try {
        const result = await sock.sendMessage(`${input.to.slice(1)}@s.whatsapp.net`, { document: Buffer.from(input.pdf), mimetype: 'application/pdf', fileName: input.filename, caption: `${input.shopName} — Invoice ${input.invoiceNumber}` })
        if (!result?.key?.id) return { state: 'unknown', error: 'Delivery could not be confirmed. Check before resending.' }
        await save({ [`message:${result.key.id}`]: encode({ message: result.message, savedAt: Date.now() }) })
        await writes
        return { state: 'accepted', messageId: result.key.id }
      } catch { return { state: 'unknown', error: 'Delivery could not be confirmed. Check before resending.' } }
    },
    stop,
    async unlink() { try { await sock?.logout() } finally { await stop() } },
  }
}
